vti_encoding:SR|utf8-nl
vti_donotpublish:BW|false
vti_timelastmodified:TR|23 Jun 2008 19:32:11 -0000
vti_title:SR|Home NewsArchiveGallery My Kippl
vti_author:SR|PYMLAPTOP\\Morten
vti_modifiedby:SR|PYMLAPTOP\\Morten
vti_nexttolasttimemodified:TR|23 Jun 2008 19:21:56 -0000
vti_timecreated:TR|23 Jun 2008 18:32:00 -0000
vti_extenderversion:SR|12.0.0.6211
vti_syncwith_localhost\\c\:\\documents and settings\\morten\\my documents\\my web sites\\mykipple 2/c\:/documents and settings/morten/my documents/my web sites/mykipple 2:TR|23 Jun 2008 18:28:54 -0000
vti_backlinkinfo:VX|contact.html Gallery/Flash/flashGallery.html Gallery/SilverlightGallery.aspx myDesk.html contact.php Contact/error.html Contact/success.html mykippleMaster.dwt myWallet.html Kipple/kenny.html default.html Contact/failure.html Kipple/bagOpennies.html
vti_cacheddtm:TX|23 Jun 2008 19:32:11 -0000
vti_filesize:IR|4683
vti_cachedtitle:SR|Home NewsArchiveGallery My Kippl
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|G|mykippleMaster.dwt Q|layout.css Q|kippleStyles.css S|Graphics/kippleSticker.png H|default.html H|myDesk.html H|myWallet.html K|contact.php H|Gallery/Flash/flashGallery.html H|Gallery/SilverlightGallery.aspx K|contact.php H|contact.html H|contact.php A|Contact/emailProcessor.php H|mailto:info@mykipple.com
vti_cachedsvcrellinks:VX|FGUS|mykippleMaster.dwt FQUS|layout.css FQUS|kippleStyles.css FSUS|Graphics/kippleSticker.png FHUS|default.html FHUS|myDesk.html FHUS|myWallet.html FKUS|contact.php FHUS|Gallery/Flash/flashGallery.html FHUS|Gallery/SilverlightGallery.aspx FKUS|contact.php FHUS|contact.html FHUS|contact.php FAUS|Contact/emailProcessor.php NHUS|mailto:info@mykipple.com
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=utf-8 keywords kippe,\\ philip\\ k\\ dick,\\ junk,\\ trash,\\ treasure description MyKipple.com\\ is\\ a\\ site\\ containing\\ pictures,\\ stories\\ and\\ info\\ on\\ all\\ my\\ kipple.
vti_charset:SR|utf-8
vti_language:SR|en-us
vti_syncwith_localhost\\c\:\\documents and settings\\morten\\my documents\\my web sites\\mykipplefinal/c\:/documents and settings/morten/my documents/my web sites/mykipplefinal:TR|23 Jun 2008 19:32:11 -0000
