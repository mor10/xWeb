vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Jun 2008 05:13:39 -0000
vti_author:SR|PYMLAPTOP\\Morten
vti_modifiedby:SR|PYMLAPTOP\\Morten
vti_nexttolasttimemodified:TR|27 Jun 2008 05:13:39 -0000
vti_timecreated:TR|23 Jun 2008 18:32:02 -0000
vti_extenderversion:SR|12.0.0.6211
vti_syncwith_localhost\\c\:\\documents and settings\\morten\\my documents\\my web sites\\mykipple 2/c\:/documents and settings/morten/my documents/my web sites/mykipple 2:TR|27 Jun 2008 05:13:39 -0000
vti_cacheddtm:TX|23 Jun 2008 18:32:02 -0000
vti_filesize:IR|8130
vti_backlinkinfo:VX|Gallery/Silverlight/SlideShow.aspx Gallery/Silverlight/SlideShow.html
vti_syncwith_localhost\\c\:\\documents and settings\\morten\\my documents\\my web sites\\mykipplefinal/c\:/documents and settings/morten/my documents/my web sites/mykipplefinal:TR|27 Jun 2008 05:13:39 -0000
