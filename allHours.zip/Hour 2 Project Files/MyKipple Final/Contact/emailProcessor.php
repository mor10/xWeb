<?php 

$to = 'morten@pinkandyellow.com';
$subject = $_POST['inquiryOptions'];
$header = $_POST['emailAddress'];
$message = "From: $fullName\nSender e-mail address: $header\nRegarding: $subject\n\nMessage:\n$thoughts\n";

if ($header=="") {
  echo "<meta http-equiv=\"refresh\" content=\"0;URL=error.html\">";
  exit;
}

$success = mail($to, $subject, $message, "From: <$header>");

if ($success){
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=success.html\">";
}
else{
	echo "<meta http-equiv=\"refresh\" content=\"0;URL=failure.html\">";
}

?>