<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- #BeginTemplate "mykippleMaster.dwt" -->

<head>
<meta content="en-us" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />

<style type="text/css">
.highlight {
	font-family: "Courier New", Courier, monospace;
	color: #800000;
	font-variant: small-caps;
	border-bottom-color: #800000;
	border-bottom-style: dotted;
	border-bottom-width: 1px;
}

</style>

<!-- #BeginEditable "keywords" --><meta content="kippe, philip k dick, junk, trash, treasure" name="keywords" /><!-- #EndEditable -->

<meta content="MyKipple.com is a site containing pictures, stories and info on all my kipple." name="description" />

<link href="layout.css" rel="stylesheet" type="text/css" />
<link href="kippleStyles.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
function FP_changeProp() {//v1.0
 var args=arguments,d=document,i,j,id=args[0],o=FP_getObjectByID(id),s,ao,v,x;
 d.$cpe=new Array(); if(o) for(i=2; i<args.length; i+=2) { v=args[i+1]; s="o"; 
 ao=args[i].split("."); for(j=0; j<ao.length; j++) { s+="."+ao[j]; if(null==eval(s)) { 
  s=null; break; } } x=new Object; x.o=o; x.n=new Array(); x.v=new Array();
 x.n[x.n.length]=s; eval("x.v[x.v.length]="+s); d.$cpe[d.$cpe.length]=x;
 if(s) eval(s+"=v"); }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}

function FP_changePropRestore() {//v1.0
 var d=document,x; if(d.$cpe) { for(i=0; i<d.$cpe.length; i++) { x=d.$cpe[i];
 if(x.v=="") x.v=""; eval("x."+x.n+"=String(x.v)"); } d.$cpe=null; }
}
// -->
</script>
<!-- #BeginEditable "doctitle" -->
	<title>Home NewsArchiveGallery My Kippl</title>
<!-- #EndEditable -->

</head>

<body>
<div id="wrapper">
<div id="header" style="left: 0px; top: 0px; height: 130px">
	<img alt="MyKipple.com" height="93" src="Graphics/kippleSticker.png" width="229" />
<div id="menu">
	<ul id="CSSmenu">
		<li><a href="default.html">Home</a>
			<ul>
				<li><a href="menus.html">News</a></li>
				<li><a href="menus.html">Archive</a></li>
			</ul>
		</li>
		<li><a href="default.html">Gallery</a>
			<ul>
				<li><a href="menus.html">My Kipple</a></li>
				<li><a href="menus.html">Other Kipple</a></li>
				<li><a href="menus.html">Found Kipple</a></li>
			</ul>
		</li>
		<li><a href="default.html">Contact</a></li>
	</ul>
</div>
</div>
<div id="content">
	
	<h1><!-- #BeginEditable "heading" -->
	<?php
	$heading = 'Contact Us' ;
	echo $heading ?>
	<!-- #EndEditable --></h1>
<!-- #BeginEditable "content" -->
	<form action="Contact/emailProcessor.php" method="post">
		<table style="width: 100%">
			<tr>
				<td>Your Name:</td>
					<td>
					<input name="fullName" type="text" size="30" tabindex="1" /></td>
					</tr>
					<tr>
						<td>Your E-mail Address:</td>
					<td>
					<input name="emailAddress" size="30" tabindex="2" type="text" /></td>
				</tr>
				<tr>
					<td>Type of Inquiry:</td>
					<td>
					<select name="inquiryOptions" tabindex="3">
					<option selected="selected">Question</option>
					<option>Comment</option>
					<option>Suggestion</option>
					<option>Kipple Story</option>
					<option>Random Thought</option>
					</select></td>
				</tr>
				<tr>
					<td>What&#39;s On Your Mind?</td>
					<td>
					<textarea cols="55" name="thoughts" rows="8" tabindex="4"></textarea></td>
				</tr>
				<tr>
					<td>Finished?</td>
					<td><input name="Submit1" type="submit" value="Submit" /><input name="Reset1" type="reset" value="Reset" /></td>
				</tr>
			</table>
		</form>
		
<!-- #EndEditable -->
	
	
</div>
<div id="footer">
<p>If you want further information about my kipple,
<a href="mailto:kippleinfo@pinkandyellow.com?subject=Email generated from the MyKipple website" title="Send all your questions about this site here">
send me an email</a>.</p>
</div>

		

</div>

</body>

<!-- #EndTemplate -->

</html>
