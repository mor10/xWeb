vti_encoding:SR|utf8-nl
vti_author:SR|PYMLAPTOP\\Morten
vti_modifiedby:SR|PYMLAPTOP\\Morten
vti_timelastmodified:TR|27 Jun 2008 05:13:39 -0000
vti_timecreated:TR|27 Jun 2008 05:12:57 -0000
vti_extenderversion:SR|12.0.0.6211
vti_backlinkinfo:VX|Gallery/Silverlight/SlideShow.aspx Gallery/Silverlight/SlideShow.html
vti_cacheddtm:TX|27 Jun 2008 05:13:39 -0000
vti_filesize:IR|8130
vti_nexttolasttimemodified:TR|27 Jun 2008 05:12:57 -0000
