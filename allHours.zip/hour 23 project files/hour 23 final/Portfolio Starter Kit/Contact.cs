﻿using System;
using System.Net.Mail;
using System.Configuration;

public partial class Contact : System.Web.UI.Page
{	
	protected void btnSend_Click(object sender, EventArgs e)
	{
		// Build the message body
		string EmailBody = "Subject: " + ConfigurationManager.AppSettings["EmailSubject"].ToString() + "\n";
        EmailBody += "Contact Name: " + this.Name.Text + "\n";
        EmailBody += "Contact Email: " + this.Email.Text + "\n";
        EmailBody += "Contact Title: " + this.TitleType.Text + "\n";
        EmailBody += "Message: " + this.Message.Text;

        MailMessage mm = new MailMessage(this.Email.Text, ConfigurationManager.AppSettings["EmailTo"].ToString());
        mm.Subject = ConfigurationManager.AppSettings["EmailSubject"].ToString();
        mm.Body = EmailBody;
        
        SmtpClient smtp = new SmtpClient();
        smtp.Send(mm);
        
        // Switch the EmailViewControl to display the confirmation message
        EmailViewControl.ActiveViewIndex = 1;
     }
}