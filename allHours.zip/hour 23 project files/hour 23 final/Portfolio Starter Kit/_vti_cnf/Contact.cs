vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Oct 2006 20:56:22 -0000
vti_extenderversion:SR|12.0.0.6211
vti_cacheddtm:TX|30 Oct 2006 20:56:22 -0000
vti_filesize:IR|1031
vti_backlinkinfo:VX|
