﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using System.Xml;

public partial class Details : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Get the requested item id from the querystring
        int itemId = Convert.ToInt32(Request.QueryString["id"]);

        // Create DataSet from XML file
        DataSet MyXML = new DataSet();
        MyXML.ReadXml(MapPath("portfolio.xml"));

        // Create PageDataSource
        PagedDataSource MyPDS = new PagedDataSource();
        MyPDS.DataSource = MyXML.Tables[0].DefaultView;
        MyPDS.AllowPaging = true;
        MyPDS.PageSize = 1;
        MyPDS.CurrentPageIndex = (itemId-1);

        // Bind the paged xml data to the DataList
        MyDataList.DataSource = MyPDS;
        MyDataList.DataBind();

		// Update 'Next' navigation button
        if (!MyPDS.IsLastPage)
        {
        	btnNext.Enabled = true;
			btnNext.ImageUrl = "images/next_off.jpg";
			btnNext.PostBackUrl = "Details.aspx?id=" + (itemId+1);
        }
        else
        {
			btnNext.Enabled = false;
            btnNext.ImageUrl = "images/next_disabled.jpg";
        }
        
        // Update 'Previous' navigation button
        if (!MyPDS.IsFirstPage)
        {
			btnPrevious.Enabled = true;
			btnPrevious.ImageUrl = "images/previous_off.jpg";
			btnPrevious.PostBackUrl = "Details.aspx?id=" + (itemId-1);
        }
        else
        {
        	btnPrevious.Enabled = false;
            btnPrevious.ImageUrl = "images/previous_disabled.jpg";
        }
        
        // Update the PageIndex label text
		Label PageIndex = (Label)MyDataList.Items[0].FindControl("PageIndex");
        PageIndex.Text = (MyPDS.CurrentPageIndex+1 + " of " + MyPDS.PageCount);
    }

    protected void MyRepeater_Init(object sender, EventArgs e)
    {
        // Set an XPath query for MyXmlDataSource (Used for thumbnail images)
        MyXmlDataSource.XPath = "portfolio/portfolioItem[@id=" + Convert.ToInt16(Request.QueryString["id"]) + "]/detailImages/image";
    }


    protected void MyRepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("ThumbSwitch"))
        {
            Image FullSizeImage = (Image)MyDataList.Items[0].FindControl("FullSizeImage");
            FullSizeImage.ImageUrl = e.CommandArgument.ToString();
        }
    }
    
    protected bool DisplayWebLink(object dataItem)
    {
    	if (dataItem.ToString().Length > 0)
    	{
        	return true;
        }
        else
        {
        	return false;
        }
	}
}